package com.example.demodocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
